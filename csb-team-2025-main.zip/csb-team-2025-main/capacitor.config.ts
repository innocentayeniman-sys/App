import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.990f7c0406c1489296c8e354f55a4e9c',
  appName: 'CSB TEAM',
  webDir: 'dist',
  server: {
    url: 'https://990f7c04-06c1-4892-96c8-e354f55a4e9c.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0
    }
  }
};

export default config;