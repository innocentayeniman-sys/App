-- Add payment tracking and notification fields to clients table
ALTER TABLE public.clients
ADD COLUMN payment_due_date TIMESTAMP WITH TIME ZONE,
ADD COLUMN is_overdue BOOLEAN DEFAULT false,
ADD COLUMN last_notification_sent TIMESTAMP WITH TIME ZONE,
ADD COLUMN payment_amount NUMERIC DEFAULT 0,
ADD COLUMN payment_date TIMESTAMP WITH TIME ZONE;

-- Add payments table for tracking payments and refunds
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payment_type TEXT NOT NULL CHECK (payment_type IN ('payment', 'refund')),
  payment_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  description TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on payments table
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- RLS policies for payments
CREATE POLICY "RA can view all payments"
ON public.payments
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

CREATE POLICY "RA can insert payments"
ON public.payments
FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

CREATE POLICY "RA can update payments"
ON public.payments
FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

CREATE POLICY "RA can delete payments"
ON public.payments
FOR DELETE
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

-- Function to calculate payment due date (30 days after registration)
CREATE OR REPLACE FUNCTION public.calculate_payment_due_date()
RETURNS trigger AS $$
BEGIN
  NEW.payment_due_date = NEW.created_at + interval '30 days';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically set payment due date
CREATE TRIGGER calculate_payment_due_date_trigger
  BEFORE INSERT ON public.clients
  FOR EACH ROW
  EXECUTE FUNCTION public.calculate_payment_due_date();

-- Function to check overdue payments
CREATE OR REPLACE FUNCTION public.update_overdue_status()
RETURNS void AS $$
BEGIN
  UPDATE public.clients
  SET is_overdue = true
  WHERE payment_due_date < now()
  AND payment_date IS NULL
  AND is_overdue = false;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for updated_at on payments
CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON public.payments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();