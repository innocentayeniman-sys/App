-- Add only missing payment tracking fields to clients table
DO $$
BEGIN
  -- Add payment_due_date if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'clients' AND column_name = 'payment_due_date') THEN
    ALTER TABLE public.clients ADD COLUMN payment_due_date TIMESTAMP WITH TIME ZONE;
  END IF;
  
  -- Add is_overdue if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'clients' AND column_name = 'is_overdue') THEN
    ALTER TABLE public.clients ADD COLUMN is_overdue BOOLEAN DEFAULT false;
  END IF;
  
  -- Add last_notification_sent if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'clients' AND column_name = 'last_notification_sent') THEN
    ALTER TABLE public.clients ADD COLUMN last_notification_sent TIMESTAMP WITH TIME ZONE;
  END IF;
  
  -- Add payment_amount if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'clients' AND column_name = 'payment_amount') THEN
    ALTER TABLE public.clients ADD COLUMN payment_amount NUMERIC DEFAULT 0;
  END IF;
  
  -- Add payment_date if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'clients' AND column_name = 'payment_date') THEN
    ALTER TABLE public.clients ADD COLUMN payment_date TIMESTAMP WITH TIME ZONE;
  END IF;
END $$;

-- Create payments table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payment_type TEXT NOT NULL CHECK (payment_type IN ('payment', 'refund')),
  payment_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  description TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on payments table if not already enabled
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_tables t 
    JOIN pg_class c ON c.relname = t.tablename 
    WHERE t.schemaname = 'public' AND t.tablename = 'payments' AND c.relrowsecurity = true
  ) THEN
    ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Create RLS policies for payments (drop if exists, then create)
DROP POLICY IF EXISTS "RA can view all payments" ON public.payments;
CREATE POLICY "RA can view all payments"
ON public.payments
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

DROP POLICY IF EXISTS "RA can insert payments" ON public.payments;
CREATE POLICY "RA can insert payments"
ON public.payments
FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

DROP POLICY IF EXISTS "RA can update payments" ON public.payments;
CREATE POLICY "RA can update payments"
ON public.payments
FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

DROP POLICY IF EXISTS "RA can delete payments" ON public.payments;
CREATE POLICY "RA can delete payments"
ON public.payments
FOR DELETE
USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = auth.uid() AND profiles.role = 'RA'
));

-- Create or replace functions
CREATE OR REPLACE FUNCTION public.calculate_payment_due_date()
RETURNS trigger AS $$
BEGIN
  NEW.payment_due_date = NEW.created_at + interval '30 days';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION public.update_overdue_status()
RETURNS void AS $$
BEGIN
  UPDATE public.clients
  SET is_overdue = true
  WHERE payment_due_date < now()
  AND payment_date IS NULL
  AND is_overdue = false;
END;
$$ LANGUAGE plpgsql;

-- Create triggers if they don't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'calculate_payment_due_date_trigger'
  ) THEN
    CREATE TRIGGER calculate_payment_due_date_trigger
      BEFORE INSERT ON public.clients
      FOR EACH ROW
      EXECUTE FUNCTION public.calculate_payment_due_date();
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_payments_updated_at'
  ) THEN
    CREATE TRIGGER update_payments_updated_at
      BEFORE UPDATE ON public.payments
      FOR EACH ROW
      EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END $$;