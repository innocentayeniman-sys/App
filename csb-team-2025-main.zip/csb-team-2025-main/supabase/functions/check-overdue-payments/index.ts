import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Client {
  id: string;
  first_name: string;
  last_name: string;
  email?: string;
  phone?: string;
  payment_due_date: string;
  is_overdue: boolean;
  last_notification_sent?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Update overdue status for all clients
    await supabaseClient.rpc('update_overdue_status');

    // Get clients who need notifications (1 week and 3 days before payment due)
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);
    
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);

    const now = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    const { data: clientsToNotify, error } = await supabaseClient
      .from('clients')
      .select('*')
      .or(
        `and(payment_due_date.lte.${oneWeekFromNow.toISOString()},payment_due_date.gte.${now.toISOString()}),` +
        `and(payment_due_date.lte.${threeDaysFromNow.toISOString()},payment_due_date.gte.${now.toISOString()})`
      )
      .is('payment_date', null)
      .or(
        `last_notification_sent.is.null,` +
        `last_notification_sent.lt.${yesterday.toISOString()}`
      );

    if (error) {
      console.error('Error fetching clients:', error);
      throw error;
    }

    console.log(`Found ${clientsToNotify?.length || 0} clients to notify`);

    let notificationsSent = 0;

    if (clientsToNotify && clientsToNotify.length > 0) {
      for (const client of clientsToNotify) {
        const paymentDueDate = new Date(client.payment_due_date);
        const daysDiff = Math.ceil((paymentDueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

        let shouldNotify = false;
        let notificationType = '';

        // Check if we should send notification (7 days or 3 days before)
        if (daysDiff <= 7 && daysDiff >= 6) {
          shouldNotify = true;
          notificationType = '1 semaine';
        } else if (daysDiff <= 3 && daysDiff >= 2) {
          shouldNotify = true;
          notificationType = '3 jours';
        }

        if (shouldNotify) {
          console.log(`Sending notification to ${client.first_name} ${client.last_name} - ${notificationType} avant échéance`);
          
          // Here you would integrate with your notification service
          // For now, we'll just log and update the notification timestamp
          
          // Update last_notification_sent
          const { error: updateError } = await supabaseClient
            .from('clients')
            .update({ last_notification_sent: now.toISOString() })
            .eq('id', client.id);

          if (updateError) {
            console.error('Error updating notification timestamp:', updateError);
          } else {
            notificationsSent++;
          }
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Processed overdue payments and sent ${notificationsSent} notifications`,
        clientsChecked: clientsToNotify?.length || 0,
        notificationsSent
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );

  } catch (error: any) {
    console.error("Error in check-overdue-payments function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

serve(handler);