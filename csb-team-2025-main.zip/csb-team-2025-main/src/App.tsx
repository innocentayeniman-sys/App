import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import { AppLayout } from "@/components/layout/AppLayout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminRegister from "./pages/AdminRegister";
import Dashboard from "./pages/Dashboard";
import AdminManagement from "./pages/AdminManagement";
import Clients from "./pages/Clients";
import AddClient from "./pages/AddClient";
import Payments from "./pages/Payments";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
        <Routes>
          {/* Auth Routes */}
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin-register" element={<AdminRegister />} />
          
          {/* App Routes */}
          <Route path="/dashboard" element={<AppLayout />}>
            <Route index element={<Dashboard />} />
          </Route>
          <Route path="/admin" element={<AppLayout />}>
            <Route index element={<AdminManagement />} />
          </Route>
          <Route path="/clients" element={<AppLayout />}>
            <Route index element={<Clients />} />
          </Route>
          <Route path="/add-client" element={<AppLayout />}>
            <Route index element={<AddClient />} />
          </Route>
          <Route path="/payments" element={<AppLayout />}>
            <Route index element={<Payments />} />
          </Route>
          <Route path="/profile" element={<AppLayout />}>
            <Route index element={<Profile />} />
          </Route>
          <Route path="/notifications" element={<AppLayout />}>
            <Route index element={<Notifications />} />
          </Route>
          
          {/* 404 */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
