import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, 
  Users, 
  UserPlus, 
  Settings, 
  User, 
  CreditCard, 
  Bell,
  Shield,
  Building2
} from 'lucide-react';
import {
  Sidebar as SidebarComponent,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  useSidebar,
} from '@/components/ui/sidebar';

// Mock user data - to be replaced with real auth
const mockUser = {
  role: 'admin', // 'admin' or 'agent'
  name: 'Admin RA'
};

const adminMenuItems = [
  { title: 'Tableau de bord', url: '/dashboard', icon: Home },
  { title: 'Gestion Admin', url: '/admin', icon: Shield },
  { title: 'Tous les clients', url: '/clients', icon: Users },
  { title: 'Remboursements', url: '/payments', icon: CreditCard },
  { title: 'Notifications', url: '/notifications', icon: Bell },
  { title: 'Profil', url: '/profile', icon: User },
];

const agentMenuItems = [
  { title: 'Tableau de bord', url: '/dashboard', icon: Home },
  { title: 'Mes clients', url: '/clients', icon: Users },
  { title: 'Ajouter client', url: '/add-client', icon: UserPlus },
  { title: 'Remboursements', url: '/payments', icon: CreditCard },
  { title: 'Profil', url: '/profile', icon: User },
];

export function Sidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;

  const menuItems = mockUser.role === 'admin' ? adminMenuItems : agentMenuItems;
  const isCollapsed = state === 'collapsed';

  const isActive = (path: string) => currentPath === path;
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? 'bg-primary/10 text-primary font-medium border-r-2 border-primary' : 'hover:bg-muted';

  return (
    <SidebarComponent className={isCollapsed ? 'w-16' : 'w-64'} collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <Building2 className="h-8 w-8 text-primary" />
          {!isCollapsed && (
            <div>
              <h2 className="text-lg font-bold text-foreground">CRM Commercial</h2>
              <p className="text-sm text-muted-foreground">Gestion des ventes</p>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} className={getNavCls}>
                      <item.icon className="h-5 w-5" />
                      {!isCollapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </SidebarComponent>
  );
}