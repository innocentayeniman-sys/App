import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  CreditCard, 
  TrendingUp, 
  Clock,
  DollarSign,
  UserPlus,
  Bell,
  CheckCircle
} from 'lucide-react';

// Mock data
const mockStats = {
  totalClients: 45,
  totalAgents: 8,
  totalRevenue: 125000,
  pendingPayments: 12,
  thisMonthClients: 12,
  thisMonthRevenue: 23000,
  pendingRegistrations: 3,
  notifications: 5
};

const recentClients = [
  { name: 'Jean Dupont', amount: 5000, agent: 'Agent 1', status: 'En cours' },
  { name: 'Marie Martin', amount: 3200, agent: 'Agent 2', status: 'Payé' },
  { name: 'Pierre Durand', amount: 7500, agent: 'Agent 1', status: 'En retard' },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Tableau de bord</h1>
        <Badge variant="outline" className="text-sm">
          Admin RA
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalClients}</div>
            <p className="text-xs text-muted-foreground">
              +{mockStats.thisMonthClients} ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Agents Actifs</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalAgents}</div>
            <p className="text-xs text-muted-foreground">
              {mockStats.pendingRegistrations} demandes en attente
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chiffre d'affaires</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalRevenue.toLocaleString()} FCFA</div>
            <p className="text-xs text-muted-foreground">
              +{mockStats.thisMonthRevenue.toLocaleString()} FCFA ce mois
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paiements en attente</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.pendingPayments}</div>
            <p className="text-xs text-muted-foreground">
              Remboursements à traiter
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Clients récents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {recentClients.map((client, index) => (
                <div key={index} className="flex items-center">
                  <div className="ml-4 space-y-1">
                    <p className="text-sm font-medium leading-none">{client.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {client.amount.toLocaleString()} FCFA - {client.agent}
                    </p>
                  </div>
                  <div className="ml-auto font-medium">
                    <Badge
                      variant={
                        client.status === 'Payé' ? 'default' :
                        client.status === 'En retard' ? 'destructive' : 'secondary'
                      }
                    >
                      {client.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Actions rapides</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-4 rounded-md border p-4">
                <Bell className="h-5 w-5 text-info" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium">Notifications</p>
                  <p className="text-sm text-muted-foreground">
                    {mockStats.notifications} nouvelles
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4 rounded-md border p-4">
                <UserPlus className="h-5 w-5 text-warning" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium">Demandes d'inscription</p>
                  <p className="text-sm text-muted-foreground">
                    {mockStats.pendingRegistrations} à valider
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4 rounded-md border p-4">
                <CheckCircle className="h-5 w-5 text-success" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium">Statut système</p>
                  <p className="text-sm text-muted-foreground">
                    Tout fonctionne normalement
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}