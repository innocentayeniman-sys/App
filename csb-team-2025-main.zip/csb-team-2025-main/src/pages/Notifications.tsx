import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Bell, 
  UserPlus, 
  CreditCard, 
  Check, 
  X, 
  Calendar,
  User,
  Coins,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Mock notifications data
const mockNotifications = [
  {
    id: 1,
    type: 'new_client',
    title: 'Nouveau client ajouté',
    message: 'Jean Dupont a été ajouté par Sophie Legrand',
    date: '2024-01-15T10:30:00Z',
    read: false,
    data: {
      clientName: 'Jean Dupont',
      agentName: 'Sophie Legrand',
      amount: 5000
    }
  },
  {
    id: 2,
    type: 'payment',
    title: 'Nouveau remboursement',
    message: 'Paiement de 1500 FCFA reçu de Marie Martin',
    date: '2024-01-15T09:15:00Z',
    read: false,
    data: {
      clientName: 'Marie Martin',
      amount: 1500,
      agentName: 'Antoine Petit'
    }
  },
  {
    id: 3,
    type: 'agent_request',
    title: 'Demande d\'inscription',
    message: 'Pierre Durand demande à devenir agent commercial',
    date: '2024-01-14T16:45:00Z',
    read: true,
    data: {
      agentName: 'Pierre Durand',
      email: 'pierre.durand@email.com'
    }
  },
  {
    id: 4,
    type: 'new_client',
    title: 'Nouveau client ajouté',
    message: 'Sophie Moreau a été ajoutée par Antoine Petit',
    date: '2024-01-14T14:20:00Z',
    read: true,
    data: {
      clientName: 'Sophie Moreau',
      agentName: 'Antoine Petit',
      amount: 4800
    }
  },
  {
    id: 5,
    type: 'payment',
    title: 'Remboursement confirmé',
    message: 'Paiement de 3200 FCFA confirmé pour Pierre Durand',
    date: '2024-01-13T11:30:00Z',
    read: true,
    data: {
      clientName: 'Pierre Durand',
      amount: 3200,
      agentName: 'Sophie Legrand'
    }
  }
];

export default function Notifications() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const { toast } = useToast();

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    toast({
      title: "Notifications marquées comme lues",
      description: "Toutes les notifications ont été marquées comme lues.",
    });
  };

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
    toast({
      title: "Notification supprimée",
      description: "La notification a été supprimée.",
    });
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'new_client':
        return <UserPlus className="h-5 w-5 text-primary" />;
      case 'payment':
        return <CreditCard className="h-5 w-5 text-success" />;
      case 'agent_request':
        return <User className="h-5 w-5 text-warning" />;
      default:
        return <Bell className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'new_client':
        return 'border-l-primary bg-primary/5';
      case 'payment':
        return 'border-l-success bg-success/5';
      case 'agent_request':
        return 'border-l-warning bg-warning/5';
      default:
        return 'border-l-muted bg-muted/5';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / 60000);
    
    if (diffInMinutes < 60) {
      return `Il y a ${diffInMinutes} minute${diffInMinutes > 1 ? 's' : ''}`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `Il y a ${hours} heure${hours > 1 ? 's' : ''}`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `Il y a ${days} jour${days > 1 ? 's' : ''}`;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold">Notifications</h1>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="text-sm">
              {unreadCount} non lue{unreadCount > 1 ? 's' : ''}
            </Badge>
          )}
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={markAllAsRead}>
            <CheckCircle className="h-4 w-4 mr-2" />
            Tout marquer comme lu
          </Button>
        )}
      </div>

      {/* Notifications List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Toutes les notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Aucune notification</p>
            </div>
          ) : (
            <div className="space-y-4">
              {notifications.map((notification, index) => (
                <div key={notification.id}>
                  <div className={`p-4 rounded-lg border-l-4 ${getNotificationColor(notification.type)} ${!notification.read ? 'bg-opacity-100' : ''}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        {getNotificationIcon(notification.type)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-sm">{notification.title}</h3>
                            {!notification.read && (
                              <Badge variant="destructive" className="text-xs px-2 py-0">
                                Nouveau
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {notification.message}
                          </p>
                          
                          {/* Additional details based on notification type */}
                          {notification.type === 'new_client' && (
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <User className="h-3 w-3" />
                                {notification.data.clientName}
                              </span>
                              <span className="flex items-center gap-1">
                                <Coins className="h-3 w-3" />
                                 {notification.data.amount.toLocaleString()} FCFA
                              </span>
                            </div>
                          )}
                          
                          {notification.type === 'payment' && (
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Coins className="h-3 w-3" />
                                {notification.data.amount.toLocaleString()} FCFA
                              </span>
                              <span className="flex items-center gap-1">
                                <User className="h-3 w-3" />
                                {notification.data.agentName}
                              </span>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
                            <Calendar className="h-3 w-3" />
                            {formatDate(notification.date)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteNotification(notification.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {index < notifications.length - 1 && <Separator className="my-4" />}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}