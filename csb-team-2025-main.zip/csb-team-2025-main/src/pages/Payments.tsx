import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Search, CreditCard, Plus, Coins, Calendar, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Payment {
  id: string;
  amount: number;
  payment_type: string;
  payment_date: string;
  description?: string;
  created_at: string;
  client_id?: string;
  clients?: {
    first_name: string;
    last_name: string;
  };
  profiles?: {
    full_name: string;
  };
}

export default function Payments() {
  const [searchTerm, setSearchTerm] = useState('');
  const [payments, setPayments] = useState<Payment[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [newPayment, setNewPayment] = useState({
    clientId: '',
    amount: '',
    description: '',
    paymentType: 'payment'
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { profile } = useAuth();

  useEffect(() => {
    if (profile?.role === 'RA') {
      fetchPayments();
      fetchClients();
    }
  }, [profile]);

  const fetchPayments = async () => {
    try {
      const { data, error } = await supabase
        .from('payments')
        .select(`
          *,
          clients (first_name, last_name),
          profiles (full_name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPayments(data || []);
    } catch (error: any) {
      console.error('Error fetching payments:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les paiements.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchClients = async () => {
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('id, first_name, last_name, is_overdue, payment_due_date')
        .order('first_name');

      if (error) throw error;
      setClients(data || []);
    } catch (error: any) {
      console.error('Error fetching clients:', error);
    }
  };

  const filteredPayments = payments.filter(payment => {
    const clientName = payment.clients ? 
      `${payment.clients.first_name} ${payment.clients.last_name}` : 
      'Client supprimé';
    const agentName = payment.profiles?.full_name || 'Agent inconnu';
    
    return clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
           agentName.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleAddPayment = async () => {
    if (!newPayment.clientId || !newPayment.amount) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive",
      });
      return;
    }

    if (!profile?.id) {
      toast({
        title: "Erreur",
        description: "Vous devez être connecté pour ajouter un paiement.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('payments')
        .insert({
          client_id: newPayment.clientId,
          amount: parseFloat(newPayment.amount),
          payment_type: newPayment.paymentType,
          description: newPayment.description || null,
          created_by: profile.id
        });

      if (error) throw error;

      // Update client payment info if it's a payment
      if (newPayment.paymentType === 'payment') {
        const { error: updateError } = await supabase
          .from('clients')
          .update({ 
            payment_date: new Date().toISOString(),
            payment_amount: parseFloat(newPayment.amount)
          })
          .eq('id', newPayment.clientId);

        if (updateError) {
          console.error('Error updating client payment info:', updateError);
        }
      }

      await fetchPayments();
      setNewPayment({
        clientId: '',
        amount: '',
        description: '',
        paymentType: 'payment'
      });
      setDialogOpen(false);
      
      toast({
        title: newPayment.paymentType === 'payment' ? "Paiement ajouté" : "Remboursement ajouté",
        description: "L'opération a été enregistrée avec succès.",
      });
    } catch (error: any) {
      console.error('Error adding payment:', error);
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de l'ajout.",
        variant: "destructive",
      });
    }
  };

  const getPaymentTypeBadge = (type: string) => {
    switch (type) {
      case 'payment':
        return <Badge variant="default">Paiement</Badge>;
      case 'refund':
        return <Badge variant="secondary">Remboursement</Badge>;
      default:
        return <Badge variant="outline">{type}</Badge>;
    }
  };

  if (profile?.role !== 'RA') {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">
          Accès réservé aux administrateurs RA
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Remboursements</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Nouveau remboursement
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ajouter un remboursement</DialogTitle>
              <DialogDescription>
                Enregistrez un nouveau paiement d'un client
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="clientId">Client *</Label>
                <select
                  id="clientId"
                  value={newPayment.clientId}
                  onChange={(e) => setNewPayment({...newPayment, clientId: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  required
                >
                  <option value="">Sélectionner un client</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.first_name} {client.last_name}
                      {client.is_overdue && ' (En retard)'}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="paymentType">Type d'opération *</Label>
                <select
                  id="paymentType"
                  value={newPayment.paymentType}
                  onChange={(e) => setNewPayment({...newPayment, paymentType: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  required
                >
                  <option value="payment">Paiement</option>
                  <option value="refund">Remboursement</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Montant *</Label>
                <Input
                  id="amount"
                  type="number"
                  min="0"
                  step="0.01"
                  value={newPayment.amount}
                  onChange={(e) => setNewPayment({...newPayment, amount: e.target.value})}
                  placeholder="1500"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={newPayment.description}
                  onChange={(e) => setNewPayment({...newPayment, description: e.target.value})}
                  placeholder="Description optionnelle"
                />
              </div>
              <Button onClick={handleAddPayment} className="w-full">
                Ajouter le remboursement
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Rechercher
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            placeholder="Rechercher par nom de client ou agent..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
        </CardContent>
      </Card>

      {/* Payments Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Historique des remboursements
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Chargement...</p>
            </div>
          ) : filteredPayments.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                {searchTerm ? 'Aucune transaction trouvée' : 'Aucune transaction enregistrée'}
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Montant</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Agent</TableHead>
                  <TableHead>Description</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">
                          {payment.clients ? 
                            `${payment.clients.first_name} ${payment.clients.last_name}` : 
                            'Client supprimé'
                          }
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getPaymentTypeBadge(payment.payment_type)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Coins className={`h-4 w-4 ${payment.payment_type === 'payment' ? 'text-success' : 'text-warning'}`} />
                        <span className={`font-semibold ${payment.payment_type === 'payment' ? 'text-success' : 'text-warning'}`}>
                          {payment.amount.toLocaleString()} FCFA
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {new Date(payment.payment_date).toLocaleDateString('fr-FR')}
                      </div>
                    </TableCell>
                    <TableCell>
                      {payment.profiles?.full_name || 'Agent inconnu'}
                    </TableCell>
                    <TableCell>
                      {payment.description || '-'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}