import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { UserPlus, Coins, Calculator, Calendar } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AddClient() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    phone: '',
    product: '',
    totalAmount: '',
    advance: '',
    installments: '2'
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { profile } = useAuth();

  const handleChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const calculateRemaining = () => {
    const total = parseFloat(formData.totalAmount) || 0;
    const advance = parseFloat(formData.advance) || 0;
    return total - advance;
  };

  const calculateInstallmentAmount = () => {
    const remaining = calculateRemaining();
    const installments = parseInt(formData.installments) || 1;
    return remaining / installments;
  };

  const isFormValid = () => {
    return formData.firstName && 
           formData.lastName && 
           formData.address && 
           formData.phone && 
           formData.product && 
           formData.totalAmount && 
           formData.advance &&
           parseFloat(formData.advance) <= parseFloat(formData.totalAmount);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isFormValid()) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs correctement.",
        variant: "destructive",
      });
      return;
    }

    if (!profile?.id) {
      toast({
        title: "Erreur",
        description: "Vous devez être connecté pour ajouter un client.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      const totalAmount = parseFloat(formData.totalAmount);
      const advance = parseFloat(formData.advance);
      const remaining = totalAmount - advance;

      const { data, error } = await supabase
        .from('clients')
        .insert({
          first_name: formData.firstName,
          last_name: formData.lastName,
          email: formData.email || null,
          phone: formData.phone,
          address: formData.address,
          product: formData.product,
          total_amount: totalAmount,
          advance: advance,
          remaining: remaining,
          installments: parseInt(formData.installments),
          agent_id: profile.id,
          status: 'En cours'
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      toast({
        title: "Client ajouté",
        description: "Le client a été ajouté avec succès avec un délai de paiement de 30 jours.",
      });
      navigate('/clients');
    } catch (error: any) {
      console.error('Error adding client:', error);
      toast({
        title: "Erreur",
        description: error.message || "Une erreur est survenue lors de l'ajout du client.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Ajouter un client</h1>
        <Badge variant="outline" className="text-sm">
          Nouveau client
        </Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Informations du client
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">Prénom *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleChange('firstName', e.target.value)}
                    placeholder="Jean"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Nom *</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleChange('lastName', e.target.value)}
                    placeholder="Dupont"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Adresse *</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                  placeholder="123 Rue de la Paix, 75001 Paris"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="client@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Téléphone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="0123456789"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="product">Produit acheté *</Label>
                <Input
                  id="product"
                  value={formData.product}
                  onChange={(e) => handleChange('product', e.target.value)}
                  placeholder="Nom du produit"
                  required
                />
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Coins className="h-5 w-5" />
                  Informations financières
                </h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="totalAmount">Montant total *</Label>
                    <Input
                      id="totalAmount"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.totalAmount}
                      onChange={(e) => handleChange('totalAmount', e.target.value)}
                      placeholder="5000"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="advance">Avance reçue *</Label>
                    <Input
                      id="advance"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.advance}
                      onChange={(e) => handleChange('advance', e.target.value)}
                      placeholder="2000"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="installments">Nombre d'échéances</Label>
                  <Select
                    value={formData.installments}
                    onValueChange={(value) => handleChange('installments', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choisir le nombre d'échéances" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 échéances</SelectItem>
                      <SelectItem value="3">3 échéances</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading || !isFormValid()}>
                {loading ? 'Ajout en cours...' : 'Ajouter le client'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Calculation Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Calcul automatique
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Montant total</Label>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-lg font-semibold">
                      {formData.totalAmount ? parseFloat(formData.totalAmount).toLocaleString() : '0'} FCFA
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Avance reçue</Label>
                  <div className="p-3 bg-success/10 rounded-lg">
                    <p className="text-lg font-semibold text-success">
                      {formData.advance ? parseFloat(formData.advance).toLocaleString() : '0'} FCFA
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Montant restant</Label>
                <div className="p-3 bg-warning/10 rounded-lg">
                  <p className="text-xl font-bold text-warning">
                    {calculateRemaining().toLocaleString()} FCFA
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Montant par échéance</Label>
                <div className="p-3 bg-info/10 rounded-lg">
                  <p className="text-lg font-semibold text-info">
                    {calculateInstallmentAmount().toLocaleString()} FCFA
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {formData.installments} échéances
                  </p>
                </div>
              </div>

              {parseFloat(formData.advance) > parseFloat(formData.totalAmount) && (
                <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                  <p className="text-sm text-destructive">
                    ⚠️ L'avance ne peut pas être supérieure au montant total
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}